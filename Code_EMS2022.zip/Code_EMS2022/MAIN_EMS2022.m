%% MAIN CODE for shallow-water waves transformation at lee-side of obstables
% Code for paper:
% Shallow-water lee-side waves at obstacles: 
% Experimental characterization and turbulent non-hydrostatic modeling using weighted-averaged residual equations 
% Authors: P. Gamero, F.N. Cantero-Chinchilla, R. Bergillos, O.
% Castro-Orgaz and Subhasish Dey
% Submitted to: Environmental Modelling and Software, 2022
clear all
clc
close all

%% Data input
Data_Read

%% Initial conditions
InitialConditions

%% VAM computations
cd VAMandSTV
VAMandSTV
cd ..

%% Plotting results
cd PlotData
PlotResults
cd ..

%% Writing results
cd Results
ResultsWriting
cd ..