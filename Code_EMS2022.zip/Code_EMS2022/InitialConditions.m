%% Subcode to compute the initial conditions for the experiments described in the previous subcode Data_Read.m

%The mesh will have N=length(x) cells
%Cells i=1, 2, N-1 and N will be used to set boundary conditions
%(Ghost cells)
x=0-2*dx:dx:leng+2*dx;

%Newton-Raphson parameters
tol=1e-16;
numero=10; 

%x at interfaces i+1/2 and i-1/2 of each cell
xL=x-dx/2;
xR=x+dx/2;

%bed profile function parameters
a=0.209;aa=a;
b=0.254;bb=b;
c=2.71;cc=c;

%zb at cell center assuming a linear variation inside the cell
for i=1:length(xL) 
    if xL(i)<9.634
        zbL(i)=0;
    else
        zbL(i)=-Cantiliver*((xL(i)-9.634)^4 -4*(leng-9.634)*(xL(i)-9.634)^3 + 6*(leng-9.634)^2 *(xL(i)-9.634)^2);
    end
end
for i=1:length(xR) 
    if xR(i)<9.634
        zbR(i)=0;
    else
        zbR(i)=-Cantiliver*((xR(i)-9.634)^4 -4*(leng-9.634)*(xR(i)-9.634)^3 + 6*(leng-9.634)^2 *(xR(i)-9.634)^2);
    end
end
for i=1:length(xL) 
    zbL(i)=zbL(i) + a*exp(-0.5*((xL(i)-(xdam-c))/b)^2) - xL(i)*Slope + Slope*9.634;
end
for i=1:length(xR) 
    zbR(i)=zbR(i) + a*exp(-0.5*((xR(i)-(xdam-c))/b)^2) - xR(i)*Slope + Slope*9.634;
end
for i=1:length(x) 
    zb(i)=(zbL(i)+zbR(i))/2;
end

%Initial conditions for a dam-break like numerical setup
% the gate is at x=1 m
h=zeros(1,length(x));
if hd/hu<=0.1
    %Tanh solution for small r ratios 
    h=0.5*(hu-hd)*(tanh(-(0.75/dx)*(x-xdam))+1)+hd -abs(zb);
else
    for i=1:length(x)
        if x(i)>xdam 
          h(i)=hd-zb(i); 
        else
          h(i)=hu-zb(i);
        end
    end
end

%Initial cell-averaged values for:
%the velocity and discharge     
u=zeros(1,length(x));
q=u.*h; 

%perturbation terms in VAM model
wmed=zeros(1,length(x));    p1=zeros(1,length(x));
p2=zeros(1,length(x));      u1=zeros(1,length(x));
diffe=zeros(1,length(x));   hwmed=zeros(1,length(x));

%Inlet discharge: the pulse is set instantaneously at t=0
q(1)=qo;
q(2)=qo;
u(1)=q(1)/h(1);
u(2)=q(2)/h(2);
h1=h(1);

%free surface elevation
zs=h+zb;

%Store previous solution
hold=h; uold=u; u1old=u1; p1old=p1; p2old=p2; 
zsold=zs; wmedold=wmed; qold=q; diffeold=diffe;