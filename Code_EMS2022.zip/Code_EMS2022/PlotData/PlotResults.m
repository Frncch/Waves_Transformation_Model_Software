%Subroutine to plot results
%Read data for different time instants
cd Exp1
    
datat0=load('t0s_allC.txt');
datat0obstacle=load('t0s_C4_obstacle.txt');
datat0bed=load('t0s_allC_bed0025.txt');
datat048=load('t048s_allC.txt');
datat1=load('t1s_allC.txt');
datat2=load('t2s_allC.txt');
datat3=load('t3s_allC.txt');
datat4=load('t4s_allC.txt');
datat5=load('t5s_allC.txt');
datat6=load('t6s_allC.txt');
datat7=load('t7s_allC.txt');
datat8=load('t8s_allC.txt');
datat9=load('t9s_allC.txt');
datat10=load('t10s_allC.txt');
datat11=load('t11s_allC.txt');
datat12=load('t12s_allC.txt');

subplot(7,2,1)
datat0(:,3)=datat0(:,2)-0.0015*datat0(:,1)+0.0015*9.634;
datat0obstacle(:,3)=datat0obstacle(:,2)-0.0015*datat0obstacle(:,1)+0.0015*9.634;
datat0bed(:,3)=datat0bed(:,2)-0.0015*datat0bed(:,1)+0.0015*9.634-0.025;
for i=1:length(datat0(:,1))
    if datat0(i,1)>=9.634
        datat0(i,3)=datat0(i,3)-Cantiliver*((datat0(i,1)-9.634).^4 -4*(leng-9.634)*(datat0(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat0(i,1)-9.634).^2);
    end
end
for i=1:length(datat0bed(:,1))
    if datat0bed(i,1)>=9.634
        datat0bed(i,3)=datat0bed(i,3)-Cantiliver*((datat0bed(i,1)-9.634).^4 -4*(leng-9.634)*(datat0bed(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat0bed(i,1)-9.634).^2);
    end
end
plot(datat0(:,1),datat0(:,3),'ksq',datat0obstacle(:,1),datat0obstacle(:,3),'rsq',datat0bed(:,1),datat0bed(:,3),'rsq',x,zbt0s,'k',x,zst0s,'b',x,zsstvt0s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=0s')
grid on

subplot(7,2,3)
datat048(:,3)=datat048(:,2)-0.0015*datat048(:,1)+0.0015*9.634;
for i=1:length(datat048(:,1))
    if datat048(i,1)>=9.634
        datat048(i,3)=datat048(i,3)-Cantiliver*((datat048(i,1)-9.634).^4 -4*(leng-9.634)*(datat048(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat048(i,1)-9.634).^2);
    end
end
plot(datat048(:,1),datat048(:,3),'ksq',x,zbt048s,'k',x,zst048s,'b',x,zsstvt048s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=0.48s')
grid on

subplot(7,2,5)
datat1(:,3)=datat1(:,2)-0.0015*datat1(:,1)+0.0015*9.634;
for i=1:length(datat1(:,1))
    if datat1(i,1)>=9.634
        datat1(i,3)=datat1(i,3)-Cantiliver*((datat1(i,1)-9.634).^4 -4*(leng-9.634)*(datat1(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat1(i,1)-9.634).^2);
    end
end
plot(datat1(:,1),datat1(:,3),'ksq',x,zbt1s,'k',x,zst1s,'b',x,zsstvt1s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=1s')
grid on

subplot(7,2,7)
datat2(:,3)=datat2(:,2)-0.0015*datat2(:,1)+0.0015*9.634;
for i=1:length(datat2(:,1))
    if datat2(i,1)>=9.634
        datat2(i,3)=datat2(i,3)-Cantiliver*((datat2(i,1)-9.634).^4 -4*(leng-9.634)*(datat2(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat2(i,1)-9.634).^2);
    end
end
plot(datat2(:,1),datat2(:,3),'ksq',x,zbt2s,'k',x,zst2s,'b',x,zsstvt2s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=2s')
grid on

subplot(7,2,9)
datat3(:,3)=datat3(:,2)-0.0015*datat3(:,1)+0.0015*9.634;
for i=1:length(datat3(:,1))
    if datat3(i,1)>=9.634
        datat3(i,3)=datat3(i,3)-Cantiliver*((datat3(i,1)-9.634).^4 -4*(leng-9.634)*(datat3(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat3(i,1)-9.634).^2);
    end
end
plot(datat3(:,1),datat3(:,3),'ksq',x,zbt3s,'k',x,zst3s,'b',x,zsstvt3s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=3s')
grid on

subplot(7,2,11)
datat4(:,3)=datat4(:,2)-0.0015*datat4(:,1)+0.0015*9.634;
for i=1:length(datat4(:,1))
    if datat4(i,1)>=9.634
        datat4(i,3)=datat4(i,3)-Cantiliver*((datat4(i,1)-9.634).^4 -4*(leng-9.634)*(datat4(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat4(i,1)-9.634).^2);
    end
end
plot(datat4(:,1),datat4(:,3),'ksq',x,zbt4s,'k',x,zst4s,'b',x,zsstvt4s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=4s')
grid on

subplot(7,2,13)
datat5(:,3)=datat5(:,2)-0.0015*datat5(:,1)+0.0015*9.634;
for i=1:length(datat5(:,1))
    if datat5(i,1)>=9.634
        datat5(i,3)=datat5(i,3)-Cantiliver*((datat5(i,1)-9.634).^4 -4*(leng-9.634)*(datat5(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat5(i,1)-9.634).^2);
    end
end
plot(datat5(:,1),datat5(:,3),'ksq',x,zbt5s,'k',x,zst5s,'b',x,zsstvt5s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=5s')
grid on

subplot(7,2,2)
datat6(:,3)=datat6(:,2)-0.0015*datat6(:,1)+0.0015*9.634;
for i=1:length(datat6(:,1))
    if datat6(i,1)>=9.634
        datat6(i,3)=datat6(i,3)-Cantiliver*((datat6(i,1)-9.634).^4 -4*(leng-9.634)*(datat6(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat6(i,1)-9.634).^2);
    end
end
plot(datat6(:,1),datat6(:,3),'ksq',x,zbt6s,'k',x,zst6s,'b',x,zsstvt6s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=6s')
grid on

subplot(7,2,4)
datat7(:,3)=datat7(:,2)-0.0015*datat7(:,1)+0.0015*9.634;
for i=1:length(datat7(:,1))
    if datat7(i,1)>=9.634
        datat7(i,3)=datat7(i,3)-Cantiliver*((datat7(i,1)-9.634).^4 -4*(leng-9.634)*(datat7(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat7(i,1)-9.634).^2);
    end
end
plot(datat7(:,1),datat7(:,3),'ksq',x,zbt7s,'k',x,zst7s,'b',x,zsstvt7s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=7s')
grid on

subplot(7,2,6)
datat8(:,3)=datat8(:,2)-0.0015*datat8(:,1)+0.0015*9.634;
for i=1:length(datat8(:,1))
    if datat8(i,1)>=9.634
        datat8(i,3)=datat8(i,3)-Cantiliver*((datat8(i,1)-9.634).^4 -4*(leng-9.634)*(datat8(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat8(i,1)-9.634).^2);
    end
end
plot(datat8(:,1),datat8(:,3),'ksq',x,zbt8s,'k',x,zst8s,'b',x,zsstvt8s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=8s')
grid on

subplot(7,2,8)
datat9(:,3)=datat9(:,2)-0.0015*datat9(:,1)+0.0015*9.634;
for i=1:length(datat9(:,1))
    if datat9(i,1)>=9.634
        datat9(i,3)=datat9(i,3)-Cantiliver*((datat9(i,1)-9.634).^4 -4*(leng-9.634)*(datat9(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat9(i,1)-9.634).^2);
    end
end
plot(datat9(:,1),datat9(:,3),'ksq',x,zbt9s,'k',x,zst9s,'b',x,zsstvt9s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=9s')
grid on

subplot(7,2,10)
datat10(:,3)=datat10(:,2)-0.0015*datat10(:,1)+0.0015*9.634;
for i=1:length(datat10(:,1))
    if datat10(i,1)>=9.634
        datat10(i,3)=datat10(i,3)-Cantiliver*((datat10(i,1)-9.634).^4 -4*(leng-9.634)*(datat10(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat10(i,1)-9.634).^2);
    end
end
plot(datat10(:,1),datat10(:,3),'ksq',x,zbt10s,'k',x,zst10s,'b',x,zsstvt10s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=10s')
grid on

subplot(7,2,12)
datat11(:,3)=datat11(:,2)-0.0015*datat11(:,1)+0.0015*9.634;
for i=1:length(datat11(:,1))
    if datat11(i,1)>=9.634
        datat11(i,3)=datat11(i,3)-Cantiliver*((datat11(i,1)-9.634).^4 -4*(leng-9.634)*(datat11(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat11(i,1)-9.634).^2);
    end
end
plot(datat11(:,1),datat11(:,3),'ksq',x,zbt11s,'k',x,zst11s,'b',x,zsstvt11s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=11s')
grid on

subplot(7,2,14)
datat12(:,3)=datat12(:,2)-0.0015*datat12(:,1)+0.0015*9.634;
for i=1:length(datat12(:,1))
    if datat12(i,1)>=9.634
        datat12(i,3)=datat12(i,3)-Cantiliver*((datat12(i,1)-9.634).^4 -4*(leng-9.634)*(datat12(i,1)-9.634).^3 + 6*(leng-9.634).^2 *(datat12(i,1)-9.634).^2);
    end
end
plot(datat12(:,1),datat12(:,3),'ksq',x,zbt12s,'k',x,zst12s,'b',x,zsstvt12s,'r','LineWidth',1.5)
axis([x(1) x(end) -0.05 0.45])
xlabel('x(m)')
ylabel('z(m)')
title('t=12s')
grid on
set(gcf,'WindowState','fullscreen')

cd ..