%% Subcode to read data of the different experiments
hu=0.302;     hd=0.12;    tail=0;     qo=0;     
Slope=0.0015;   Cantiliver=0.00001; 
inlet=4;  outlet=2; n=0.01; dx=0.02; 
CFL=0.2; Tmax=12.05; tol=1e-6;
%General data
g=9.81;
ro=1000;
Flim=0.2;
htol=tol;
limit=1; %1-minmod; 2-superbee
leng=15;
xdam=7.5+1.775;
