%StV variables
hstv=h; ustv=u; qstv=q;

%free surface elevation
zs=h+zb;
zsstv=hstv+zb;

%Store previous solution
holdstv=hstv; uoldstv=ustv; qoldstv=qstv;
hold=h; uold=u; u1old=u1; p1old=p1; p2old=p2; 
zsold=zs; wmedold=wmed; qold=q; diffeold=diffe;