%Limitation of jumps in conserved variables
%If lambda=(1, Minmod limiter; 2, Superbee)
lambda=1;

if (DU * DD) < 0 
    delta = 0;
else
    sig = sign(DU);
    a = abs(DU);
    b = abs(DD);


    if a < b
        d1 = a;
    else
        d1 = b;
    end

    d1 = lambda * d1;


    if a > b
        d2 = a;
    else
        d2 = b;
    end


    if d1 < d2
        factor = d1;
    else
        factor = d2;
    end

factor = factor * sig;
delta = factor;

end