%Singular Cells routine
clear SingCell SingCellcenter SingCellminus SingCellplus
SingCell=NaN;SingCellcenter=NaN;SingCellminus=NaN;SingCellplus=NaN;SingCellminus2=NaN;SingCellplus2=NaN;
lindex=1;
angle=75;
%Non-dimensional gradients of the perturbation parameters and variables
dzbhdx=ddx(zb+h,dx);
du02gdx=ddx((q./h).^2 /g,dx);
du12gdx=ddx(u1.^2 /g,dx);
dp1gammadx=ddx(p1/ro/g,dx);
dp2gammadx=ddx(p2/ro/g,dx);
dwmed2gdx=ddx(wmed.^2 /g,dx);
if t>sqrt(hu/g)
    for i=3:length(x)-2
            if abs(dzbhdx(i))>tan(angle*pi/180) || abs(du02gdx(i))>tan(angle*pi/180) || abs(du12gdx(i))>tan(angle*pi/180) ||  abs(dp1gammadx(i))>tan(angle*pi/180) || abs(dp2gammadx(i))>tan(angle*pi/180) || abs(dwmed2gdx(i))>tan(angle*pi/180) || i>=length(x)-2 
                 SingCellcenter(lindex)=i;
                 SingCellminus(lindex)=i-1;
                 SingCellplus(lindex)=i+1;
                 SingCellminus2(lindex)=i-2;
                 SingCellplus2(lindex)=i+2;
                 lindex=lindex+1;
            end
    end
end
SingCell=sort([SingCellcenter,SingCellminus,SingCellplus]);
%SingCell=sort([SingCellcenter,SingCellminus,SingCellplus,SingCellminus2,SingCellplus2]);