%% Minmod limiter of 3 numbers
function minm=minmod3rd(e1,e2,e3)
%minm=sign(e1)*max(0,min([e1,sign(e1)*e2,sign(e1)*e3]));
if sign(e1)==sign(e2)
    if sign(e2)==sign(e3)
        minm=sign(e1)*min([abs(e1),abs(e2),abs(e3)]);
    else
        minm=0;
    end
else
    minm=0;
end

% 
% if e2 == 0
%     sig=1;
% else
%     sig=e2/abs(e2);
% end
% 
% a1=abs(e1);
% a2=2*sig*e2;
% a3=2*sig*e3;
% 
% if a1<a2 
%     a4=a1;
% else
%     a4=a2;
% end
% 
% if a3<a4
%     a4=a3;
% end
% 
% 
% if a4<0 
%     a4=0;
% end
% 
% minm=sig*a4;
