% Non-Homogeneous step for the de Saint-Venant equations
% Track position of the dry bed cells to apply or not ghdzTerm when NR is
% not updating Uhyperbolic
DrybedTrack
S=[0*x;
   -0*ghdzbdxTerm(1,:);
   0*x;
   0*x;
   0*x;
   0*x;
   -ghdzbdxTerm(2,:)];
U=[h; q+dt*S(2,:); h.*u1; h.*wmed; (h.^2).*diffe/12; hstv; qstv+dt*S(7,:)];
h=U(1,:);      q=U(2,:);          
u1=U(3,:)./h;     wmed=U(4,:)./h;     diffe=12*U(5,:)./(h.^2);   
hstv=U(6,:);   qstv=U(7,:); 
for i=1:length(x)
    if h(i)<htol
        q(i)=0; u1(i)=0; wmed(i)=0; diffe(i)=0;
    end
    if hstv(i)<htol
        qstv(i)=0; 
    end
    if h(i)<0
        h(i)=0; q(i)=0; u1(i)=0; wmed(i)=0; diffe(i)=0;
    end
    if hstv(i)<0
        hstv(i)=0; qstv(i)=0; 
    end
end