function Terms=PartDeriv(h,q,u1,wmed,diffe,dx,dt,ro,dzmeddx,dhdx,dzbdx,dzbhdx,i,htol)

%x-momentum equation
%r1 derivates. In order: qi-1,u1i-1,p1i-1,p2i-1,wmedi-1,diffei-1,qi,u1i,p1i,p2i,wmedi,diffei,qi+1,u1i+1,p1i+1,p2i+1,wmedi+1,diffei+1
Terms(1)=0;
Terms(2)=-(dt/dx)*h(i-1)*u1(i-1)/3;
Terms(3)=-(dt/(4*ro*dx))*h(i-1);
Terms(4)=-(dt/(3*ro*dx))*h(i-1);
Terms(5)=0;
Terms(6)=0;
Terms(7)=1;
Terms(8)=0;
Terms(9)=(dt/ro)*dzbdx(i);
Terms(10)=0;
Terms(11)=0;
Terms(12)=0;
Terms(13)=0;
Terms(14)=(dt/dx)*h(i+1)*u1(i+1)/3;
Terms(15)=(dt/(4*ro*dx))*h(i+1);
Terms(16)=(dt/(3*ro*dx))*h(i+1);
Terms(17)=0;
Terms(18)=0;

%moment of x-momentum equation
%r2 derivates. In order: qi-1,u1i-1,p1i-1,p2i-1,wmedi-1,diffei-1,qi,u1i,p1i,p2i,wmedi,diffei,qi+1,u1i+1,p1i+1,p2i+1,wmedi+1,diffei+1
Terms(19)=-dt*u1(i)/(2*dx);
Terms(20)=0;
Terms(21)=dt*h(i)/(4*ro*dx);
Terms(22)=0;
Terms(23)=0;
Terms(24)=0;
Terms(25)=-dt*u1(i)*dhdx(i)/h(i); if h(i)<=htol; Terms(25)=0; end
Terms(26)=h(i)-dt*(q(i)*dhdx(i)/h(i) - (q(i+1)-q(i-1))/(2*dx));
Terms(27)=dt*dhdx(i)/(2*ro);     
Terms(28)=4*dt*dzmeddx(i)/(ro); 
Terms(29)=0;
Terms(30)=0;
Terms(31)=dt*u1(i)/(2*dx);
Terms(32)=0;
Terms(33)=-dt*h(i)/(4*ro*dx);
Terms(34)=0;
Terms(35)=0;
Terms(36)=0;

%z-momentum equation
%r3 derivates. In order: qi-1,u1i-1,p1i-1,p2i-1,wmedi-1,diffei-1,qi,u1i,p1i,p2i,wmedi,diffei,qi+1,u1i+1,p1i+1,p2i+1,wmedi+1,diffei+1
Terms(37)=0;
Terms(38)=(dt/(12*dx))*h(i-1)*diffe(i-1);
Terms(39)=0;
Terms(40)=0;
Terms(41)=0;
Terms(42)=(dt/(12*dx))*h(i-1)*u1(i-1);
Terms(43)=0;
Terms(44)=0;
Terms(45)=-dt/ro;
Terms(46)=0;
Terms(47)=h(i);
Terms(48)=0;
Terms(49)=0;
Terms(50)=-(dt/(12*dx))*h(i+1)*diffe(i+1);
Terms(51)=0;
Terms(52)=0;
Terms(53)=0;
Terms(54)=-(dt/(12*dx))*h(i+1)*u1(i+1);

%moment of z-momentum equation
%r4 derivates. In order: qi-1,u1i-1,p1i-1,p2i-1,wmedi-1,diffei-1,qi,u1i,p1i,p2i,wmedi,diffei,qi+1,u1i+1,p1i+1,p2i+1,wmedi+1,diffei+1
Terms(55)=(dt/(120*dx*dx))*( 2*dx*(3*q(i)*dzbhdx(i)+3*q(i)*dzbdx(i)+h(i-1)*u1(i-1)*(dzbhdx(i-1)+dzbdx(i-1))) -3*h(i)*(q(i+1)-q(i-1)+2*(-u1(i)*dzbhdx(i)+u1(i)*dzbdx(i)+7*wmed(i))*dx));
Terms(56)=(h(i-1)*dt/(120*dx*dx))*(2*q(i-1)*dx*(dzbhdx(i-1)+dzbdx(i-1)) + h(i-1)*(-q(i)+q(i-2)+4*dx*u1(i-1)*dzbhdx(i-1)-4*dx*u1(i-1)*dzbdx(i-1)+6*wmed(i-1)*dx));
Terms(57)=0;
Terms(58)=0;
Terms(59)=h(i-1)*h(i-1)*u1(i-1)*dt/(20*dx);
Terms(60)=0;
Terms(61)=-(dt/(120*dx*dx*(h(i)^(4/3))))*((h(i)^(4/3))*h(i+1)*u1(i+1)*(q(i+1)+h(i+1)*u1(i+1))*dzbhdx(i+1) -12*(h(i)^(1/3))*q(i)*dx*dx*(dzbhdx(i)+dzbdx(i))^2  +  (h(i)^(4/3))*( h(i-1)^2*u1(i-1)+6*dx*(-2*u1(i)*dx*dzbhdx(i)^2 + 2*u1(i)*dx*dzbdx(i)^2 + 20*wmed(i)*dx*dzmeddx(i)+ (q(i+1)-q(i-1)+4*wmed(i)*dx)*dzbhdx(i) + (q(i+1)-q(i-1)+4*wmed(i)*dx)*dzbdx(i)) ));
Terms(62)=-dt*(-(1/6)*h(i)*diffe(i)*dzmeddx(i)  -(1/(20*dx))*((dzbhdx(i)-dzbdx(i))*(2*q(i)*dx*(dzbhdx(i)+dzbdx(i))+h(i)*(-q(i+1)+q(i-1)+2*u1(i)*dx*dzbhdx(i)-2*u1(i)*dx*dzbdx(i)-4*wmed(i)*dx))));
Terms(63)=0;
Terms(64)=2*h(i)*dt/(3*ro);
Terms(65)=dt/(20*dx)*(-4*q(i)*dx*(dzbhdx(i)+dzbdx(i)+5*dzmeddx(i))+ h(i)*(7*q(i+1)-7*q(i-1)-4*dx*u1(i)*dzbhdx(i)+4*dx*u1(i)*dzbdx(i)+48*wmed(i)*dx));
Terms(66)=h(i)*(h(i)+2*dt*(diffe(i)+u1(i)*dzmeddx(i)))/12;
Terms(67)=(dt/(120*dx*dx))*(h(i+1)*u1(i+1)*(-q(i)+q(i+2))*dzbhdx(i+1) - 2*dx*(3*q(i)*dzbhdx(i)+3*q(i)*dzbdx(i)+h(i+1)*u1(i+1)*dzbdx(i+1)) + 3*h(i)*(q(i+1)-q(i-1)-2*u1(i)*dx*dzbhdx(i) +2*u1(i)*dx*dzbdx(i) + 14*wmed(i)*dx));
Terms(68)=-(h(i+1)*dt/(120*dx*dx))*(6*h(i+1)*wmed(i+1)*dx + 2*dx*(q(i+1)-2*h(i+1)*u1(i+1))*dzbdx(i+1) + (q(i)-q(i+2))*(q(i+1)+2*h(i+1)*u1(i+1))*dzbhdx(i+1));
Terms(69)=0;
Terms(70)=0;
Terms(71)=-h(i+1)*h(i+1)*u1(i+1)*dt/(20*dx);
Terms(72)=0;

%moment of continuity equation
%r5 derivates. In order: qi-1,u1i-1,p1i-1,p2i-1,wmedi-1,diffei-1,qi,u1i,p1i,p2i,wmedi,diffei,qi+1,u1i+1,p1i+1,p2i+1,wmedi+1,diffei+1
Terms(73)=-h(i)/(4*dx);
Terms(74)=h(i-1)*h(i-1)/(12*dx);
Terms(75)=0;
Terms(76)=0;
Terms(77)=0;
Terms(78)=0;
Terms(79)=-dzmeddx(i);
Terms(80)=0;
Terms(81)=0;
Terms(82)=0;
Terms(83)=h(i);
Terms(84)=0;
Terms(85)=h(i)/(4*dx);
Terms(86)=-h(i+1)*h(i+1)/(12*dx);
Terms(87)=0;
Terms(88)=0;
Terms(89)=0;
Terms(90)=0;

%kinematic boundary conditions
%r6 derivates. In order: qi-1,u1i-1,p1i-1,p2i-1,wmedi-1,diffei-1,qi,u1i,p1i,p2i,wmedi,diffei,qi+1,u1i+1,p1i+1,p2i+1,wmedi+1,diffei+1
Terms(91)=h(i)*h(i)/(24*dx);
Terms(92)=0;
Terms(93)=0;
Terms(94)=0;
Terms(95)=0;
Terms(96)=0;
Terms(97)=-h(i)*(dzbdx(i)-dzbhdx(i))/12;
Terms(98)=h(i)*h(i)*(dzbdx(i)+dzbhdx(i))/12;
Terms(99)=0;
Terms(100)=0;
Terms(101)=0;
Terms(102)=h(i)*h(i)/12;
Terms(103)=-h(i)*h(i)/(24*dx);
Terms(104)=0;
Terms(105)=0;
Terms(106)=0;
Terms(107)=0;
Terms(108)=0;

