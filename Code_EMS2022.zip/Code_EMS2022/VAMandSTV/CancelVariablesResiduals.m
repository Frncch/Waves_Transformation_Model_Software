%No update of variables in the face of a hydraulic jump but q
for k=1:length(SingCell)
    if i==SingCell(k)
%       varcancel='p1var';
%       if strcmp(varcancel,'p1var')
%           BB(6*i-3)=0;
%       end
%       varcancel='p2var';
%       if strcmp(varcancel,'p2var')
%           BB(6*i-2)=0;
%       end
%       varcancel='u1';
%       if strcmp(varcancel,'u1')
%           BB(6*i-4)=0;
%       end
%       varcancel='wmed';
%       if strcmp(varcancel,'wmed')
%           BB(6*i-1)=0;
%       end
%       varcancel='diffe';
%       if strcmp(varcancel,'diffe')
%           BB(6*i  )=0;
%       end
        BB(6*i-5)=-r1stv(i);
        BB(6*i-4)=0;
        BB(6*i-3)=0;
        BB(6*i-2)=0;
        BB(6*i-1)=0;
        BB(6*i  )=0;
        
    end
end