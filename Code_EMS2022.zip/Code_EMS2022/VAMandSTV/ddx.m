function hx = ddx(h,dx)

for i=1:length(h)
    if i==1 || i==2
        hx(i)=(h(i+1)-h(i))/(dx); hx(i)=0;
    elseif i==length(h) || i==length(h)-1
        hx(i)=(h(i)-h(i-1))/(dx); hx(i)=0;
    else
        hx(i)=(h(i+1)-h(i-1))/(2*dx); 
    end
end
