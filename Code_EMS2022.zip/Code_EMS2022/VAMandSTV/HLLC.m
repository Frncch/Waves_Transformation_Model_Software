% HLLC approximate Riemann solver
function [Fintercell] = HLLC (eq,FL,FR,UL,UR,hL,hR,uL,uR,g,htol)

if hL==0
    VL=0;
else
    VL=uL;
end
CL=sqrt(g*hL);

if hR==0
    VR=0;
else
    VR=uR;
end
CR=sqrt(g*hR);

SS=0.5*(VL+VR)+(CL-CR);

ind=0;
%Dry-bed filters in HLLC by Kim et al. (2007)
if hR<htol && hL>htol && ind==0;   SL=VL-CL;   SR=VL+2*CL; SS=SR;   ind=1;  end
if hL<htol && hR>htol && ind==0;   SL=VR-2*CR; SR=VR+CR;   SS=SL;   ind=1;  end
if hL<htol && hR<htol && ind==0;   SL=-htol;   SR=htol;    SS=htol; ind=1;  end

if ind==0
    DS=(0.5*(CL+CR)+0.25*(VL-VR))^2 /g;
    
    %Wet bed with correction factor
    if DS<=hL
        SL=VL-CL;
    else
        SL=VL-CL*sqrt(0.5*DS*(DS+hL))/hL;
        SL=min(VL-CL,SS-sqrt(g*DS)); %HLLC by Kim et al. (2007)
    end
    
    if DS<=hR
        SR=VR+CR;
    else
        SR=VR+CR*sqrt(0.5*DS*(DS+hR))/hR;
        SR=min(VR+CR,SS+sqrt(g*DS)); %HLLC by Kim et al. (2007)
    end
end

%Start variables
switch eq
    case 1
        varL=1;
        varR=1;
    case 2
        varL=SS;
        varR=SS;
    case 3
        varL=UL/hL; if hL==0; varL=0; end
        varR=UR/hR; if hR==0; varR=0; end
    case 4
        varL=UL/hL; if hL==0; varL=0; end
        varR=UR/hR; if hR==0; varR=0; end
    case 5
        varL=UL/hL; if hL==0; varL=0; end
        varR=UR/hR; if hR==0; varR=0; end
end
ULS=hL*varL*(SL-VL)/(SL-SS); if isnan(ULS); ULS=0; end
URS=hR*varR*(SR-VR)/(SR-SS); if isnan(URS); URS=0; end

%Godunov intercell flux with HLLC
if SL >=0
    Fintercell=FL;
end
if SL<=0 && SS >=0
    FLS=FL + SL*(ULS-UL);
    Fintercell=FLS;
end
if SS<=0 && SR >=0
    FRS=FR + SR*(URS-UR);
    Fintercell=FRS;
end
if SR <=0
    Fintercell=FR;
end


% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% function [Fintercell] = HLLC (indi,FL,FR,UL,UR,hL,hR,uL,uR,g,htol)
%  %HLLC
%  
%  if isnan(uL) || uL==Inf || uL==-Inf
%      uL=0; 
%  end
%  if isnan(uR) || uR==Inf || uR==-Inf
%      uR=0; 
%  end
%  if isnan(FL) || FL==Inf || FL==-Inf
%      FL=0; 
%  end
%  if isnan(FR)  || FR==Inf || FR==-Inf
%      FR=0; 
%  end
%  if isnan(UL)  || UL==Inf || UL==-Inf
%      UL=0; 
%  end
%  if isnan(UR)   || UR==Inf || UR==-Inf
%      UR=0;
%  end
%  
%  %long-wave celerities
%  aL=sqrt(hL*g);    
%  aR=sqrt(hR*g);
%  
%  %estimation of star region depth and velocity
%  %see Eq.(64)
%  hast=(1/g)*((1/2)*(aL+aR)+(1/4)*(uL-uR))^2;
%  %see Eq.(61)
%  uast=(1/2)*(uL+uR)+(aL-aR);
%  
%  %compute signal celerities for shock and rarefaction waves
%  %see Eq.(63)
%     if hast>hL
%        qL=sqrt((hast+hL)*hast/(2*hL^2)); if hL<=htol; qL=0; end
%     else
%        qL=1;
%     end
%     if hast>hR
%        qR=sqrt((hast+hR)*hast/(2*hR^2)); if hR<=htol; qR=0; end
%     else
%        qR=1;
%     end
%     
%     %see Eqs.(62)
%     SL=uL-aL*qL; 
%     S1=SL;
%     SR=uR+aR*qR; 
%     S3=SR;
%     %see Eq.(61)
%     Sast=uast;   
%     S2=Sast; 
%     
%     %Dry-bed filters
%     if hR<=htol && hL>=htol;   SL=uL-aL;   SR=uL+2*aL; S1=SL; S3=SR; end
%     if hL<=htol && hR>=htol;   SL=uR-2*aR; SR=uR+aR;   S1=SL; S3=SR; end
%     if hL<=htol && hR<=htol;   SL=-htol;   SR=htol;    S1=SL; S3=SR; end
%     
%     %Computation of UL,R*; see Eq.(60)
%         if indi==1 
%             UastL=hL*(SL-uL)/(SL-Sast); 
%             if isnan(UastL)
%                 UastL=0; 
%             end
%             UastR=hR*(SR-uR)/(SR-Sast); 
%             if isnan(UastR)
%                 UastR=0; 
%             end
%         elseif indi==2
%             UastL=hL*Sast*(SL-uL)/(SL-Sast); 
%             if isnan(UastL)
%                 UastL=0; 
%             end
%             UastR=hR*Sast*(SR-uR)/(SR-Sast); 
%             if isnan(UastR)
%                 UastR=0; 
%             end
%         elseif indi==3
%             cL=UL/(hL); if hL<=htol; cL=0; end
%             cR=UR/(hR); if hR<=htol; cR=0; end
%             UastL=cL*hL*(SL-uL)/(SL-Sast);
%             if isnan(UastL)
%                 UastL=0;
%             end
%             UastR=cR*hR*(SR-uR)/(SR-Sast); 
%             if isnan(UastR)
%                 UastR=0; 
%             end
%         elseif indi==4
%             QbL=UL*Sast;  
%             QbR=UR*Sast;
%             UastL=(QbL/Sast)*(SL-uL)/(SL-Sast); 
%             if isnan(UastL)
%                 UastL=0; 
%             end
%             UastR=(QbR/Sast)*(SR-uR)/(SR-Sast); 
%             if isnan(UastR)
%                 UastR=0; 
%             end
%         end
%         
%  %Evaluations of the flux function; see Eqs.(58)-(59)
%  F1=FL;   
%  F2=FL + SL*(UastL-UL);
%  F3=FR + SR*(UastR-UR);
%  F4=FR;
% 
%  %Determination of the numerical flux at the interface; see Eq.(57)
%  
%  if S1>0
%      Fintercell=F1;
%  elseif S1<=0 && S2>0
%      Fintercell=F2;
%  elseif S2<=0 && S3>0
%      Fintercell=F3;
%  else
%      Fintercell=F4;
%  end
