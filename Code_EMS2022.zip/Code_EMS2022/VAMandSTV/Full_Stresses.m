%% Sub-routine to compute full stress terms in VAM model
%sigmax, sigmaz and tauxz stand for sigmax_bar, sigmaz_bar and tauxz_bar,
%respectively
zs=zb+h;
us=q./h + u1;
ub=q./h - u1;
ws=-ddx(q,dx) + us.*ddx(zs,dx); 
wb=ub.*ddx(zb,dx); 
sigmax=(2*ro.*nux./h).*(ddx(q,dx)-us.*ddx(zs,dx)+ub.*ddx(zb,dx));
sigmaz=2*ro.*nuz.*(ws-wb)./h; 
tauxz=(ro*nuz./h).*(us-ub + ddx(h.*wmed,dx) - ws.*ddx(zs,dx) + wb.*ddx(zb,dx));
zsigmax=(nux.*ro.*h/3).*(3.*ddx(q./h,dx)+ddx(u1,dx)) - (nux.*ro.*u1.*zb/h).*(2.*ddx(h,dx) + 4.*ddx(zb,dx)) - (nux.*ro./3).*(4.*u1.*ddx(h,dx)-6.*zb.*ddx(q./h,dx)+6.*u1.*ddx(zb,dx));
w2=3*(wmed-wb/2-ws/2)/2;
ztauxz=nuz.*ro.*u1 + 2.*nuz.*ro.*u1.*zb./h +(nuz.*ro.*h./3).*ddx(wb/2 + ws + w2,dx) + nuz.*ro.*(wb-ws+2*w2).*ddx(h,dx)/3 + nuz.*ro.*zb.*ddx(wb/2+ws/2+2*w2/3,dx) + nuz.*ro.*(wb/2-ws/2+2*w2/3).*ddx(zb,dx) + nuz.*ro.*zb.*(wb/2-ws/2+2*w2/3).*ddx(h,dx)./h + nuz.*ro.*(wb-ws).*zb.*ddx(zb,dx)./h;
%ztauxz=nuz.*ro.*u1 + 2.*nuz.*ro.*u1.*zb./h + (nuz.*ro.*h./2).*ddx(wmed-wb/6+ws/6,dx) + nuz.*ro.*(wmed - wb/6 - 5*ws/6).*ddx(h,dx) + nuz.*ro.*zb.*ddx(wmed,dx) + nuz.*ro.*(wb-ws).*ddx(zb,dx) + nuz.*ro.*zb.*(wmed-ws).*ddx(h,dx)./h + nuz.*ro.*(wb-ws).*zb.*ddx(zb,dx)./h;