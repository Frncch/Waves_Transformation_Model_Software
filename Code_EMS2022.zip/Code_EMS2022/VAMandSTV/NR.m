%% ------Newton-Raphson iteracion of the implicit inviscid step------------
%A dry bed filter is inserted into the NR as follows. If h(i)<=htol, then
%the update vector of the variables q, p1, p2, wmed and diffe in i cell
%must be 0. To impose that, in the matrix operation K*updates=BB, the BB
%slots corresponding to i are set to 0. Besides, K slots corresponding to i
%are set to 0 but the diagonal, which is imposed to be 1. Therefore, the
%operation is forced to read: 1*update(i)=0, that yields update(i)=0. 

%NOTE: if the drybed filter is set after the matrix operation, it is
%artificial, that is all the variables had been calculated with non-zero
%values of the rest of variables. However, the drybed filter makes 0 some
%of them. To sum up, the non-zero variables have the information of the
%real variables which have been artificially imposed to read 0. 

%Inizialitation of variables for iterations of the Newton-Raphson scheme
q=q;
p1=zeros(1,length(x));
p2=zeros(1,length(x));
u1=zeros(1,length(x));
wmed=zeros(1,length(x));
diffe=zeros(1,length(x));

%Inizialization of arrays for NR method
act=ones(1,length(x));
BB=act;
iter=1;
vect=ones(1,6*length(x));   

%Compute Frozen Jacobian K
FrozenJacobian

while iter<numero && sqrt(sum(act.^2)/sum(vect.^2))>tol
     
    %Update variables
    zs=zb+h;
    zmed=zb+h/2; 
    dqdx=ddx(q,dx);
    dzbhdx=ddx(zb+h,dx);
    dzbdx=ddx(zb,dx);
    wb=(q./h - u1).*dzbdx;
    wh=-dqdx + (q./h + u1).*dzbhdx;
    for i=1:length(x) %Dry-bed filter
        if h(i)<=htol
            wb(i)=(- u1(i)).*dzbdx(i);
            wh(i)=-dqdx(i) + (+ u1(i)).*dzbhdx(i);
        end
    end
    w2med=wmed.^2 + (diffe.^2)/12 +(1/20).*(2*wmed-wb-wh).^2;
    dzmeddx=ddx(zmed,dx); 
    r1derv=(h.*u1.^2)/3 + (h.*p1)./(2*ro) + (2*h.*p2)./(3*ro);
    dr1dx=ddx(r1derv,dx);  
    dhdx=ddx(h,dx); 
    dp1dx=ddx(p1,dx);     
    r3derv=h.*u1.*diffe;
    dr3dx=ddx(r3derv,dx); 
    r4derv=h.*h.*u1.*(wmed + wb/3 + wh/3)/10;
    dr4dx=ddx(r4derv,dx); 
    r6derv=h.*h.*u1;
    dr6dx=ddx(r6derv,dx); 
    
    %Constants
    %x-momentum equation
    C1=-Uhat(2,:)-dt*(-ghdzbdxTerm(1,:));
    %moment of x-momentum equation
    C2=-Uhat(3,:);
    %z-momentum equation
    C3=-Uhat(4,:);
    %moment of z-momentum equation
    C4=-Uhat(5,:);
    %moment of continuity equation (reactive)
    C5=0;
    %kinematic boundary conditions (reactive)
    C6=0;
    
    
    %Residuals
    %x-momentum equation STV
    r1stv=q + C1;
    %x-momentum equation;
    r1=q + C1 - dt*( -dr1dx -p1.*dzbdx./ro );
    %moment of x-momentum equation; new equation for transport variable h*u1 instead of u1
    r2=h.*u1 + C2 - dt*( h.*dp1dx/(2*ro) + (q.*u1./h - p1/(2*ro)).*dhdx - u1.*dqdx - 4*p2.*dzmeddx./ro );
    for i=1:length(x) %Dry-bed filter
        if h(i)<=htol
            r2(i)=h(i)*u1(i) + C2(i) - dt*( h(i)*dp1dx(i)/(2*ro) + (- p1(i)/(2*ro))*dhdx(i) -u1(i)*dqdx(i) -4*p2(i)*dzmeddx(i)/ro );
        end
    end
    %z-momentum equation; 
    r3=h.*wmed + C3 - dt*( (1/6)*dr3dx + p1./ro );
    %moment of z-momentum equation; 
    r4=h.*h.*diffe/12 + C4 - dt*( -0.5*h.*wmed.*dqdx + (q.*wmed - h.*u1.*diffe/6).*dzmeddx + dr4dx - h.*w2med - 2*h.*p2./(3.*ro));
    %moment of continuity equation (reactive); 
    r5=h.*wmed + 0.5*h.*dqdx - q.*dzmeddx - dr6dx/6;
    %kinematic boundary conditions (reactive); 
    r6=h.*h.*diffe/12 - h.*h.*wb/12 + h.*h.*wh/12; 
    
    for i=1:length(x)
        BB(6*i-5)=-r1(i);
        BB(6*i-4)=-r2(i);
        BB(6*i-3)=-r3(i);
        BB(6*i-2)=-r4(i);
        BB(6*i-1)=-r5(i);
        BB(6*i  )=-r6(i);
        %filters 
        if i>2 && i<length(x)-1
            %No update of variables in the face of a hydraulic jump but q
            CancelVariablesResiduals
            %Dry bed filter
            DrybedNRresiduals
        end
    end

    %Compute vector for actualization of variables;
     act=sparse(K)\sparse(BB');
     act=full(act);
     %FreadAlgorithm
     for i=1:length(act)
         if isnan(act(i)) || act(i)==Inf || act(i)==-Inf
             act(i)=0;
         end
     end     
     
     %Update solution
     l=1;
    for i=1:length(x)
        q(i)=q(i)+ act(l);
        u1(i)=u1(i)+ act(l+1);
        p1(i)=p1(i)+ act(l+2);
        p2(i)=p2(i)+ act(l+3);
        wmed(i)=wmed(i)+ act(l+4);
        diffe(i)=diffe(i)+ act(l+5);
        l=l+6;
    end
    l=1;

    %Vector of variables for stopping criteria
    for i=1:length(x)
        vect(l)=q(i);
        vect(l+1)=u1(i);
        vect(l+2)=p1(i);
        vect(l+3)=p2(i);
        vect(l+4)=wmed(i);
        vect(l+5)=diffe(i);
        l=l+6;
    end
    iter=iter+1;
end

