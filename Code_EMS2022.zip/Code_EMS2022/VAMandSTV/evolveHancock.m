%Computation of vector fluxes associated with PIL and PIR

%STV
FIL(6)=PIL(7);          
FIR(6)=PIR(7);
if PIL(6)<=0
    FIL(7)=0;
else
    FIL(7)=PIL(6)*(PIL(7)/PIL(6))^2 + 0.5*g*(PIL(6)^2); 
end
if PIR(6)<=0
    FIR(7)=0;
else
    FIR(7)=PIR(6)*(PIR(7)/PIR(6))^2 + 0.5*g*(PIR(6)^2);
end

%VAM
FIL(1)=PIL(2);          
FIR(1)=PIR(2);
if PIL(1)<=0
    FIL(2)=0;
    FIL(3)=0;
    FIL(4)=0;
    FIL(5)=0;
else
    FIL(2)=PIL(1)*(PIL(2)/PIL(1))^2 + 0.5*g*(PIL(1)^2); 
    FIL(3)=PIL(3)*PIL(2)/PIL(1);
    FIL(4)=PIL(4)*PIL(2)/PIL(1);
    FIL(5)=PIL(5)*PIL(2)/PIL(1);
end
if PIR(1)<=0
    FIR(2)=0;
    FIR(3)=0;
    FIR(4)=0;
    FIR(5)=0;
else
    FIR(2)=PIR(1)*(PIR(2)/PIR(1))^2 + 0.5*g*(PIR(1)^2);
    FIR(3)=PIR(3)*PIR(2)/PIR(1);
    FIR(4)=PIR(4)*PIR(2)/PIR(1);
    FIR(5)=PIR(5)*PIR(2)/PIR(1);
end

%bed source term effect STV
%z-jump in the bed profile within a cell
%cell full filled with water
zjumpSTV(i)=(zbR(i)-zbL(i));

%cell partially-filled with water, with zero water depth on its right side
if PIR(6)<=htol 
    zjumpSTV(i)=PIL(6);
end

%cell partially-filled with water, with zero water depth on its left side
if PIL(6)<=htol
    zjumpSTV(i)=-PIR(6);
end

%bed source term effect VAM
%z-jump in the bed profile within a cell
%cell full filled with water
zjump(i)=(zbR(i)-zbL(i));

%cell partially-filled with water, with zero water depth on its right side
if PIR(1)<=htol 
    zjump(i)=PIL(1);
end

%cell partially-filled with water, with zero water depth on its left side
if PIL(1)<=htol
    zjump(i)=-PIR(1);
end



deltasource(1)=0;
deltasource(2)=-g*(PIL(1) + PIR(1))*0.5*zjump(i)/dx; 
deltasource(3)=0;
deltasource(4)=0;
deltasource(5)=0;
deltasource(6)=0;
deltasource(7)=-g*(PIL(6) + PIR(6))*0.5*zjumpSTV(i)/dx;