%Dry bed filter 
if h(i)<=htol || h(i-1)<=htol || h(i+1)<=htol %|| h(i-2)<=htol || h(i+2)<=htol 
    BB(6*i-5)=0;
    BB(6*i-4)=0;
    BB(6*i-3)=0;
    BB(6*i-2)=0;
    BB(6*i-1)=0;
    BB(6*i  )=0;
end