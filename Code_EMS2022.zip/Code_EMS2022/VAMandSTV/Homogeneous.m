%HomogeneoUhats step for the nUhatmerical method (advancing in time)

%Computation of dflux/dx within a cell
dfluxdx=zeros(7,length(x));
for i=3:length(x)-2
    dfluxdx(:,i)=(Flux(:,i)-Flux(:,i-1))/dx;
end

Uhat=Uold-dt*dfluxdx; 
h=Uhat(1,:);        q=Uhat(2,:);   qHomo=q;       
u1=Uhat(3,:)./h;    wmed=Uhat(4,:)./h;     diffe=12*Uhat(5,:)./(h.^2);   
hstv=Uhat(6,:);  qstv=Uhat(7,:); 
for i=1:length(x)
    if h(i)<htol
        q(i)=0; u1(i)=0; wmed(i)=0; diffe(i)=0;
    end
    if hstv(i)<htol
        qstv(i)=0; 
    end
    if h(i)<0
        h(i)=0; q(i)=0; u1(i)=0; wmed(i)=0; diffe(i)=0;
    end
    if hstv(i)<0
        hstv(i)=0; qstv(i)=0; 
    end
end