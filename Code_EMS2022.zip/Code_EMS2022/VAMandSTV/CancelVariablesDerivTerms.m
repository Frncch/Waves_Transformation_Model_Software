%No update of variables in the face of a hydraulic jump but q
for k=1:length(SingCell)
    if i==SingCell(k)
        for kk=1:length(Terms)
            Terms(kk)=0;
        end
        Terms(7)=1;  %q
        Terms(26)=1; %u1
        Terms(45)=1; %p1
        Terms(64)=1; %p2
        Terms(83)=1; %wmed
        Terms(102)=1;%diffe
    end
end