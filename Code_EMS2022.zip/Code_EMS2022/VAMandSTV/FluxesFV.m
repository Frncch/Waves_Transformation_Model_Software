%% Finite volume - Godunov-type Fluxes
flux=zeros(7,length(x));
gh=zeros(2,length(x));
dzbjump=zeros(2,length(x));

for i=3:length(x)-2
              %Flux at interface i+1/2
                %Left state
                hL=BEXT(2,1,i); 
                qL=BEXT(2,2,i);
                u1L=BEXT(2,3,i); 
                hwmedL=BEXT(2,4,i);
                diffeL=BEXT(2,5,i);
                hLstv=BEXT(2,6,i); 
                qLstv=BEXT(2,7,i);
                
                %Right state
                hR=BEXT(1,1,i+1); 
                qR=BEXT(1,2,i+1); 
                u1R=BEXT(1,3,i+1); 
                hwmedR=BEXT(1,4,i+1);
                diffeR=BEXT(1,5,i+1);
                hRstv=BEXT(1,6,i+1); 
                qRstv=BEXT(1,7,i+1); 
                
                %for gravity term
                hp05=hL;
                hp05stv=hLstv;
                
                %VAM vector of unknows evaluated for states L and R
                U1L=hL;         U1R=hR;  
                U2L=qL;         U2R=qR;
                U3L=u1L;        U3R=u1R;  
                U4L=hwmedL;     U4R=hwmedR;   
                U5L=diffeL;     U5R=diffeR; 
                U6L=hLstv;      U6R=hRstv;  
                U7L=qLstv;      U7R=qRstv; 
                
                %Flux vector evaluated at L and R states
                F1L=U2L;                                F1R=U2R;     
                F2L=U1L*(U2L/U1L)^2 + 0.5*g*(U1L^2);    F2R=U1R*(U2R/U1R)^2 + 0.5*g*(U1R^2); 
                F3L=U3L*(U2L/U1L);                      F3R=U3R*(U2R/U1R); 
                F4L=U4L*(U2L/U1L);                      F4R=U4R*(U2R/U1R); 
                F5L=U5L*(U2L/U1L);                      F5R=U5R*(U2R/U1R); 
                F6L=U7L;                                F6R=U7R;     
                F7L=U6L*(U7L/U6L)^2 + 0.5*g*(U6L^2);    F7R=U6R*(U7R/U6R)^2 + 0.5*g*(U6R^2); 
                
                % check dry bed conditions
                if hL==0
                    F2L=0; F3L=0; F4L=0; F5L=0; 
                end
                if hR==0
                    F2R=0; F3R=0; F4R=0; F5R=0;
                end
                if hLstv==0
                    F7L=0;  
                end
                if hRstv==0
                    F7R=0; 
                end
                
                %HLLC numerical flux
                %continuity 
                [Fcontp05(i)]=HLLC(1,F1L,F1R,U1L,U1R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %x-momentum
                [Fxmp05(i)]=HLLC(2,F2L,F2R,U2L,U2R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %z-momentum
                [Fzmp05(i)]=HLLC(3,F3L,F3R,U3L,U3R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %moment x-momentum
                [Fmxmp05(i)]=HLLC(4,F4L,F4R,U4L,U4R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %moment z-momentum
                [Fmzmp05(i)]=HLLC(5,F5L,F5R,U5L,U5R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %continuity STV
                [Fcontp05stv(i)]=HLLC(1,F6L,F6R,U6L,U6R,U6L,U6R,U7L/U6L,U7R/U6R,g,htol); 
                %x-momentum STV
                [Fxmp05stv(i)]=HLLC(2,F7L,F7R,U7L,U7R,U6L,U6R,U7L/U6L,U7R/U6R,g,htol); 
               
                
              %Flux at i-1/2
                %Left state
                hL=BEXT(2,1,i-1); 
                qL=BEXT(2,2,i-1);
                u1L=BEXT(2,3,i-1); 
                hwmedL=BEXT(2,4,i-1);
                diffeL=BEXT(2,5,i-1);
                hLstv=BEXT(2,6,i-1); 
                qLstv=BEXT(2,7,i-1); 
                
                %Right state
                hR=BEXT(1,1,i); 
                qR=BEXT(1,2,i); 
                u1R=BEXT(1,3,i); 
                hwmedR=BEXT(1,4,i);
                diffeR=BEXT(1,5,i);
                hRstv=BEXT(1,6,i); 
                qRstv=BEXT(1,7,i); 
                
                %for gravity term
                hm05=hR;
                hm05stv=hRstv;
                                
                %VAM vector of unknows evaluated for states L and R
                U1L=hL;         U1R=hR;  
                U2L=qL;         U2R=qR;
                U3L=u1L;        U3R=u1R;  
                U4L=hwmedL;     U4R=hwmedR;   
                U5L=diffeL;     U5R=diffeR; 
                U6L=hLstv;      U6R=hRstv;  
                U7L=qLstv;      U7R=qRstv;  
                
                %Flux vector evaluated at L and R states
                F1L=U2L;                                F1R=U2R;     
                F2L=U1L*(U2L/U1L)^2 + 0.5*g*(U1L^2);    F2R=U1R*(U2R/U1R)^2 + 0.5*g*(U1R^2); 
                F3L=U3L*(U2L/U1L);                      F3R=U3R*(U2R/U1R); 
                F4L=U4L*(U2L/U1L);                      F4R=U4R*(U2R/U1R); 
                F5L=U5L*(U2L/U1L);                      F5R=U5R*(U2R/U1R); 
                F6L=U7L;                                F6R=U7R;     
                F7L=U6L*(U7L/U6L)^2 + 0.5*g*(U6L^2);    F7R=U6R*(U7R/U6R)^2 + 0.5*g*(U6R^2); 
                
                % check dry bed conditions
                if hL==0
                    F2L=0; F3L=0; F4L=0; F5L=0; 
                end
                if hR==0
                    F2R=0; F3R=0; F4R=0; F5R=0;
                end
                if hLstv==0
                    F7L=0;  
                end
                if hRstv==0
                    F7R=0; 
                end
                
                %HLLC numerical flux
                %continuity 
                [Fcontm05(i)]=HLLC(1,F1L,F1R,U1L,U1R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %x-momentum
                [Fxmm05(i)]=HLLC(2,F2L,F2R,U2L,U2R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %z-momentum
                [Fzmm05(i)]=HLLC(3,F3L,F3R,U3L,U3R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %moment x-momentum
                [Fmxmm05(i)]=HLLC(4,F4L,F4R,U4L,U4R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %moment z-momentum
                [Fmzmm05(i)]=HLLC(5,F5L,F5R,U5L,U5R,U1L,U1R,U2L/U1L,U2R/U1R,g,htol); 
                %continuity STV
                [Fcontm05stv(i)]=HLLC(1,F6L,F6R,U6L,U6R,U6L,U6R,U7L/U6L,U7R/U6R,g,htol); 
                %x-momentum STV
                [Fxmm05stv(i)]=HLLC(2,F7L,F7R,U7L,U7R,U6L,U6R,U7L/U6L,U7R/U6R,g,htol); 
                 
               %Compute well-balanced ghdzb/dx term               
               gh(1,i)=g*0.5*(hp05+hm05); 
               gh(2,i)=g*0.5*(hp05stv+hm05stv); 
                              
               %Computation of well-balanced ghdzbdx gravity term
                zm05=zbL(i);
                zp05=zbR(i);
                dzbjump(1,i)=(zp05-zm05);
                dzbjump(2,i)=(zp05-zm05);
                if hp05<=htol %right-part of the cell dry, left-part wet VAM
                    dzbjump(1,i)=hm05;
                end
                if hm05<=htol %left-part of the cell dry, right-part wet VAM
                    dzbjump(1,i)=-hp05;
                end       
                if hp05stv<=htol %right-part of the cell dry, left-part wet STV
                    dzbjump(2,i)=hm05stv;
                end
                if hm05stv<=htol %left-part of the cell dry, right-part wet STV
                    dzbjump(2,i)=-hp05stv;
                end       
                        
                              
              %FLUX MATRIX              
              % fluxes(k,i)=Fi+1/2(k)-Fi-1/2(k)              
              %                                        Variable determined
              %                                        ___________________
              %k=1(continuity equation)----------------Computation of h
              % =2(x-momentum equation)----------------Computation of q 
              % =3(z-momentum equation)----------------Computation of u1  
              % =4(moment x-momentum equation)---------Computation of hwmed  
              % =5(moment z-momentum equation)---------Computation of diffe  
              % =6(STV continuity equation)------------Computation of hstv  
              % =7(STV x-momentum equation)------------Computation of qstv  
              flux(1,i)=Fcontp05(i)-Fcontm05(i);
              flux(2,i)=Fxmp05(i)-Fxmm05(i);
              flux(3,i)=Fzmp05(i)-Fzmm05(i);
              flux(4,i)=Fmxmp05(i)-Fmxmm05(i);
              flux(5,i)=Fmzmp05(i)-Fmzmm05(i);
              flux(6,i)=Fcontp05stv(i)-Fcontm05stv(i);
              flux(7,i)=Fxmp05stv(i)-Fxmm05stv(i);
end

dzbwellbaldx=dzbjump/dx;
ghdzbdx=gh.*dzbwellbaldx;