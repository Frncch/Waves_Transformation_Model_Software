%STV
FDL(6)=CDL(7);          
FDR(6)=CDR(7);
if CDL(6)<=0
    FDL(7)=0;
else
    FDL(7)=CDL(6)*(CDL(7)/CDL(6))^2 + 0.5*g*(CDL(6)^2); 
end
if CDR(6)<=0
    FDR(7)=0;
else
    FDR(7)=CDR(6)*(CDR(7)/CDR(6))^2 + 0.5*g*(CDR(6)^2);
end