%-------------------------------Turbulent explicit step-----------------
%bottom vertical velocity
dzbdx=ddx(zb,dx);
wb=(q./h - u1).*dzbdx; 
for i=1:length(x)
    if h(i)<=htol
        wb(i)=(- u1(i)).*dzbdx(i);
    end
end
%bed shear stress tangential to the boundary
Rh=(h.*0.405)./(2*h+0.405);
taub=sign(q).*ro.*g.*n.*n.*((q./h - u1).^2 + wb.^2)./(Rh.^(1/3));
for i=1:length(x)
    if h(i)<=htol
        taub(i)=0;
    end
end
%Turbulence closure (Ghamry and Steffler, 2002; and Full Stress terms)
ust=((taub/ro).^2).^(1/4);
nux=0.5*ust.*h;
nuz=0.07*ust.*h;
Full_Stresses
for i=1:length(x)
    if h(i)<=htol || isnan(dqdx(i))
        sigmax(i)=0;
        sigmaz(i)=0;
        tauxz(i)=0;
    end
end

%Update the solution with Sv
qaux=q;
q=q+dt*(-ddx(-h.*sigmax/ro,dx)-taub/ro);
wmed=(h.*wmed + dt*(-taub.*dzbdx/ro + ddx(h.*tauxz,dx)/ro))./h;
u1=u1 + dt*((6./(h*ro)).*(taub/2 - tauxz)) + dt*((6./((h.^2)*ro)).*(ddx(h.*zsigmax,dx) - (zb+h/2).*ddx(h.*sigmax,dx)));
diffe=(h.*h.*diffe/12 + dt*(-h.*taub.*dzbdx/(2*ro) + h.*sigmaz/ro - (ddx(h.*ztauxz,dx) - (zb+h/2).*ddx(h.*tauxz,dx))/ro))./(h.*h./12);
for i=1:length(x)                                                    
    if h(i)<=htol
        q(i)=0;        wmed(i)=0;        diffe(i)=0;
    else
        %Friction can stop the flow, but a flow reversal is not physically feasible
        if qaux(i)*q(i)<0; q(i)=0; end
    end
end

%Saint-Venant
Rhstv=(hstv.*0.405)./(2*hstv+0.405);
taubstv=sign(qstv).*ro.*g.*n.*n.*((qstv./hstv).^2)./(Rhstv.^(1/3));
for i=1:length(x)
    if hstv(i)<=htol
        taubstv(i)=0;
    end
end
qstvaux=qstv;
qstv=qstv-dt*taubstv/ro;
for i=1:length(x)
    if hstv(i)<=htol
        qstv(i)=0; 
    else
        %Friction can stop the flow, but a flow reversal is not physically feasible
        if qstvaux(i)*qstv(i)<0; qstv(i)=0; end
    end 
end