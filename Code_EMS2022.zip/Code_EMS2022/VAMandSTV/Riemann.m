%% HLLC Riemann solver for interface fluxes Fi+1/2
Flux=zeros(7,length(x));
for i=2:length(x)-2
    % Assignation of values for Riemann problem at interface i+1/2 of cell i. CDR and CDL are the vectors of variables U at the right (R)
    % and left (L) side of the interface i+1/2 of cell i
    for k=1:5
        CDL(k)=BEXT(2, k, i);
        CDR(k)=BEXT(1, k, i + 1);
    end
    %Transformation to physical variables and check dry bed conditions
    hL=CDL(1);
    if hL==0
        VL=0;
    else
        VL=CDL(2)/hL;
    end
    CL=sqrt(g*hL);

    hR=CDR(1);
    if hR==0
        VR=0;
    else
        VR=CDR(2)/hR;
    end
    CR=sqrt(g*hR);
    
    %Computation of vector fluxes FDL an FDR at interface i+1/2 of cell i
    VectorFD

    %Interface speeds
    option=2;
    switch option
        case 1
            Kim2007HLLC
        case 2
            ToroShockBookHLLC
    end
    
    %Dry-bed filters in HLLC by Kim et al. (2007)
    if hR<=htol && hL>=htol;   SL=VL-CL;   SR=VL+2*CL; SS=SR;   end
    if hL<=htol && hR>=htol;   SL=VR-2*CR; SR=VR+CR;   SS=SL;   end
    if hL<=htol && hR<=htol;   SL=-htol;   SR=htol;    SS=htol; end

    %Start variables
    for eq=1:5
        switch eq
            case 1
                varL=1;
                varR=1;
            case 2
                varL=SS;
                varR=SS;
            case 3
                varL=CDL(eq)/hL; if hL==0; varL=0; end
                varR=CDR(eq)/hR; if hR==0; varR=0; end
            case 4
                varL=CDL(eq)/hL; if hL==0; varL=0; end
                varR=CDR(eq)/hR; if hR==0; varR=0; end
            case 5
                varL=CDL(eq)/hL; if hL==0; varL=0; end
                varR=CDR(eq)/hR; if hR==0; varR=0; end
            case 6
                varL=1;
                varR=1;
            case 7
                varL=SS;
                varR=SS;
        end
        ULS(eq)=hL*varL*(SL-VL)/(SL-SS); if isnan(ULS(eq)); ULS(eq)=0; end
        URS(eq)=hR*varR*(SR-VR)/(SR-SS); if isnan(URS(eq)); URS(eq)=0; end
    end
    %Godunov intercell flux with HLLC
    if SL >=0
        for k=1:5
            Flux(k,i)=FDL(k);
        end
    end
    if SL<=0 && SS >=0
        for k=1:5
            FLS=FDL(k) + SL*(ULS(k)-CDL(k));
            Flux(k,i)=FLS;
        end
    end
    if SS<=0 && SR >=0
        for k=1:5
            FRS=FDR(k) + SR*(URS(k)-CDR(k));
            Flux(k,i)=FRS;
        end
    end
    if SR <=0
        for k=1:5
            Flux(k,i)=FDR(k);
        end
    end
end