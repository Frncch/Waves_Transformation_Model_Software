%% Track position of the dry bed cells to apply or not ghdzTerm when NR is not updating Uhyperbolic
ApplyghdzTerm=zeros(1,length(x));
if t>sqrt(hu/g)
    for i=3:length(x)-2
        if h(i)<=htol  || h(i-1)<=htol || h(i+1)<=htol  || h(i-2)<=htol || h(i+2)<=htol 
            ApplyghdzTerm(i)=1;
        end
    end
else
    ApplyghdzTerm=ones(1,length(x));
end
ApplyghdzTerm(1)=1;
ApplyghdzTerm(2)=1;
ApplyghdzTerm(length(x)-1)=1;
ApplyghdzTerm(length(x))=1;