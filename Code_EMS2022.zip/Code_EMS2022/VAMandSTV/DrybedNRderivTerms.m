%Dry bed filter
if h(i)<=htol  || h(i-1)<=htol || h(i+1)<=htol %|| h(i-2)<=htol || h(i+2)<=htol 
    for kk=1:length(Terms)
        Terms(kk)=0;
    end
    Terms(7)=1;  %q
    Terms(26)=1; %u1
    Terms(45)=1; %p1
    Terms(64)=1; %p2
    Terms(83)=1; %wmed
    Terms(102)=1;%diffe
end