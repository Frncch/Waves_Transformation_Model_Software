%% Numerical solution for VAM and STV equations
t=0; 
count=1;
InitialCond
%Tmax-loop
while t<Tmax 
%VAM and Saint-Venant variables vector
Uvector

%CFL condition
CFLcon

%------------------MUSCL-HANCOCK 2th order reconstruction------------------
MUSCL

%----------------Numerical Flux using HLLC Riemann solver------------------
Riemann 
RiemannSTV 

%--------------------------Gravity-Bed Slope term--------------------------
GraBedTerm

%--------Advance solution in time using the finite volume method-----------
AdvanceTime

%Store previous solution
holdstv=hstv;   qoldstv=qstv;
hold=h;         qold=q;         u1old=u1;       p1old=p1;        
p2old=p2;       wmedold=wmed;   diffeold=diffe;

%Ghost Cells to set boundary conditions
BoundCond

%free surface elevation
zs=h+zb;
zsstv=hstv+zb;

%Storage solutions for data save
StorageSolutions

%Instantaneous Plot
PlotRoutine

%Update dt and count
count=count+1;
t=t + dt;
end 

PlotRoutine
