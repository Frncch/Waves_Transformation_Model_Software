%% HLLC extracted from Toro 2001 (Shock-capturing...BOOK), pg178-182
%Estimation of h* (DS) and u* (SS)
optionDSSS=2;
switch optionDSSS
    case 1 %A Exact depth positivity Riemann solver (pg178)
        DS=0.5*(hL+hR)-0.25*(VR-VL)/(hL+hR)/(CL+CR);
        SS=0.5*(VL+VR)-(hR-hL)*(CL+CR)/(hL+hR);
    case 2 %A two-rarefaction Riemann solver (pg178-179)
        DS=(0.5*(CR+CL) + 0.25*(VL-VR))^2 /g;
        SS=0.5*(VL+VR)+CL-CR;
    case 3 %A two-shock Riemann solver (pg179)
        ho=(0.5*(CR+CL) + 0.25*(VL-VR))^2 /g;
        gLho=(0.5*g*(ho+hL)/(ho*hL))^0.5;
        gRho=(0.5*g*(ho+hR)/(ho*hR))^0.5;
        DS=(gLho*hL+gRho*hR+VL-VR)/(gLho+gRho);
        SS=0.5*(VL+VR)+0.5*((DS-hR)*gRho-(DS-hL)*gLho);
    case 4 %Attractive alternative (Eq. 10.27)
        DS=(0.5*(CR+CL) + 0.25*(VL-VR))^2 /g;
end


%Wet bed with correction factor
if hL<=htol
    qL=0;
else
    if DS>hL
        qL=(0.5*DS*(DS+hL)/(hL^2))^0.5;
    else
        qL=1;
    end
end
if hR<=htol
    qR=0;
else
    if DS>hR
        qR=(0.5*DS*(DS+hR)/(hR^2))^0.5;
    else
        qR=1;
    end
end
SL=VL-CL*qL;
SR=VR+CR*qR;

switch optionDSSS
    case 4 %Attractive alternative (Eq. 10.27)
        SS=(SL*hR*(VR-SR)-SR*hL*(VL-SL))/(hR*(VR-SR)-hL*(VL-SL));
end

