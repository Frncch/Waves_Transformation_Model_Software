%-----------------------------Homogeneus step------------------------------
Homogeneous
%------------------------------Inviscid Step-------------------------------
NR
%--------------------Non-Homogeneus step for StV equations-----------------
NonHomogeneousSTV
%--------------------------Turbulent viscous step--------------------------
TurbulentViscous_GhamrySteffler2002

