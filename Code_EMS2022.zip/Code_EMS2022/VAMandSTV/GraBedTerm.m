%% Evaluation of source term from bed profile
ghdzbdxTerm=zeros(2,length(x));
for i=2:length(x)-1
    %Computation of the bed z-jump within a cell
    %cell full-filled with water
    zjump(1,i)=(zbR(i)-zbL(i));
    zjump(2,i)=(zbR(i)-zbL(i));
    
    %cell partially-filled with water, with zero water depth on its right
    %side
    if BEXT(2,1,i)<=htol
        zjump(1,i)=BEXT(1,1,i);
    end
    if BEXT(2,6,i)<=htol
        zjump(2,i)=BEXT(1,6,i);
    end
    
    %cell partially-filled with water, with zero water depth on its left
    %side
    if BEXT(1,1,i)<=htol
        zjump(1,i)=-BEXT(2,1,i);
    end
    if BEXT(1,6,i)<=htol
        zjump(2,i)=-BEXT(2,6,i);
    end
    
    ghdzbdxTerm(1,i)=g*(BEXT(1,1,i)+BEXT(2,1,i))*0.5*zjump(1,i)/dx;
    ghdzbdxTerm(2,i)=g*(BEXT(1,6,i)+BEXT(2,6,i))*0.5*zjump(2,i)/dx;
end