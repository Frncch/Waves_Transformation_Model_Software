%VAM
FDL(1)=CDL(2);         
FDR(1)=CDR(2);
if CDL(1)<=0
    FDL(2)=0;
    FDL(3)=0;
    FDL(4)=0;
    FDL(5)=0;
else
    FDL(2)=CDL(1)*(CDL(2)/CDL(1))^2 + 0.5*g*(CDL(1)^2); 
    FDL(3)=CDL(3)*CDL(2)/CDL(1);
    FDL(4)=CDL(4)*CDL(2)/CDL(1);
    FDL(5)=CDL(5)*CDL(2)/CDL(1);
end
if CDR(1)<=0
    FDR(2)=0;
    FDR(3)=0;
    FDR(4)=0;
    FDR(5)=0;
else
    FDR(2)=CDR(1)*(CDR(2)/CDR(1))^2 + 0.5*g*(CDR(1)^2);
    FDR(3)=CDR(3)*CDR(2)/CDR(1);
    FDR(4)=CDR(4)*CDR(2)/CDR(1);
    FDR(5)=CDR(5)*CDR(2)/CDR(1);
end