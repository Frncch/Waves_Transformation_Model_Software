%% minmod limiter
function x = minmod(i,j)
x=zeros(length(i),1);
for c=1:length(i)
        x(c) = sign(i(c)).*max(0,min(abs(i(c)),sign(i(c))*j(c)));
end