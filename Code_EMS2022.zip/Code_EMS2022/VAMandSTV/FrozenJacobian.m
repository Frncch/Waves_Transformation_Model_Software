%Update variables
    zs=zb+h;
    zmed=zb+h/2; 
    dqdx=ddx(q,dx);
    dzbhdx=ddx(zb+h,dx);
    dzbdx=ddx(zb,dx);
    wb=(q./h - u1).*dzbdx;
    wh=-dqdx + (q./h + u1).*dzbhdx;
    for i=1:length(x) %Dry-bed filter
        if h(i)<=htol
            wb(i)=(- u1(i)).*dzbdx(i);
            wh(i)=-dqdx(i) + (+ u1(i)).*dzbhdx(i);
        end
    end
    w2med=wmed.^2 + (diffe.^2)/12 +(1/20).*(2*wmed-wb-wh).^2;
    dzmeddx=ddx(zmed,dx);
    dhdx=ddx(h,dx); 
    
    %Singular cells routine
    SingularCells
    
    %Fill Jacobian matrix with zeros
    K=zeros(6*length(x),6*length(x));
    
    %Fill the elements of the Jacobian matrix corresponding to the
    %computational domain     
    for i=3:length(x)-2
        
      %Partial derivatives in Jacobian matrix
      Terms=PartDeriv(h,q,u1,wmed,diffe,dx,dt,ro,dzmeddx,dhdx,dzbdx,dzbhdx,i,htol);
      
      %Dry-bed filter NR Terms PartDeriv
      DrybedNRderivTerms

      %Cancel Terms for SingCells
      CancelVariablesDerivTerms
      
      %Computed analytical elements
      K(6*i-5,6*i-11)=Terms(1);  K(6*i-5,6*i-10)=Terms(2);    K(6*i-5,6*i-9)=Terms(3);    K(6*i-5,6*i-8)=Terms(4);  K(6*i-5,6*i-7)=Terms(5);     K(6*i-5,6*i-6)=Terms(6);     K(6*i-5,6*i-5)=Terms(7);     K(6*i-5,6*i-4)=Terms(8);     K(6*i-5,6*i-3)=Terms(9);     K(6*i-5,6*i-2)=Terms(10);    K(6*i-5,6*i-1)=Terms(11);    K(6*i-5,6*i)=Terms(12);   K(6*i-5,6*i+1)=Terms(13); K(6*i-5,6*i+2)=Terms(14); K(6*i-5,6*i+3)=Terms(15); K(6*i-5,6*i+4)=Terms(16); K(6*i-5,6*i+5)=Terms(17); K(6*i-5,6*i+6)=Terms(18);              
      K(6*i-4,6*i-11)=Terms(19); K(6*i-4,6*i-10)=Terms(20);   K(6*i-4,6*i-9)=Terms(21);   K(6*i-4,6*i-8)=Terms(22); K(6*i-4,6*i-7)=Terms(23);    K(6*i-4,6*i-6)=Terms(24);    K(6*i-4,6*i-5)=Terms(25);    K(6*i-4,6*i-4)=Terms(26);    K(6*i-4,6*i-3)=Terms(27);    K(6*i-4,6*i-2)=Terms(28);    K(6*i-4,6*i-1)=Terms(29);    K(6*i-4,6*i)=Terms(30);   K(6*i-4,6*i+1)=Terms(31); K(6*i-4,6*i+2)=Terms(32); K(6*i-4,6*i+3)=Terms(33); K(6*i-4,6*i+4)=Terms(34); K(6*i-4,6*i+5)=Terms(35); K(6*i-4,6*i+6)=Terms(36);
      K(6*i-3,6*i-11)=Terms(37); K(6*i-3,6*i-10)=Terms(38);   K(6*i-3,6*i-9)=Terms(39);   K(6*i-3,6*i-8)=Terms(40); K(6*i-3,6*i-7)=Terms(41);    K(6*i-3,6*i-6)=Terms(42);    K(6*i-3,6*i-5)=Terms(43);    K(6*i-3,6*i-4)=Terms(44);    K(6*i-3,6*i-3)=Terms(45);    K(6*i-3,6*i-2)=Terms(46);    K(6*i-3,6*i-1)=Terms(47);    K(6*i-3,6*i)=Terms(48);   K(6*i-3,6*i+1)=Terms(49); K(6*i-3,6*i+2)=Terms(50); K(6*i-3,6*i+3)=Terms(51); K(6*i-3,6*i+4)=Terms(52); K(6*i-3,6*i+5)=Terms(53); K(6*i-3,6*i+6)=Terms(54);
      K(6*i-2,6*i-11)=Terms(55); K(6*i-2,6*i-10)=Terms(56);   K(6*i-2,6*i-9)=Terms(57);   K(6*i-2,6*i-8)=Terms(58); K(6*i-2,6*i-7)=Terms(59);    K(6*i-2,6*i-6)=Terms(60);    K(6*i-2,6*i-5)=Terms(61);    K(6*i-2,6*i-4)=Terms(62);    K(6*i-2,6*i-3)=Terms(63);    K(6*i-2,6*i-2)=Terms(64);    K(6*i-2,6*i-1)=Terms(65);    K(6*i-2,6*i)=Terms(66);   K(6*i-2,6*i+1)=Terms(67); K(6*i-2,6*i+2)=Terms(68); K(6*i-2,6*i+3)=Terms(69); K(6*i-2,6*i+4)=Terms(70); K(6*i-2,6*i+5)=Terms(71); K(6*i-2,6*i+6)=Terms(72);
      K(6*i-1,6*i-11)=Terms(73); K(6*i-1,6*i-10)=Terms(74);   K(6*i-1,6*i-9)=Terms(75);   K(6*i-1,6*i-8)=Terms(76); K(6*i-1,6*i-7)=Terms(77);    K(6*i-1,6*i-6)=Terms(78);    K(6*i-1,6*i-5)=Terms(79);    K(6*i-1,6*i-4)=Terms(80);    K(6*i-1,6*i-3)=Terms(81);    K(6*i-1,6*i-2)=Terms(82);    K(6*i-1,6*i-1)=Terms(83);    K(6*i-1,6*i)=Terms(84);   K(6*i-1,6*i+1)=Terms(85); K(6*i-1,6*i+2)=Terms(86); K(6*i-1,6*i+3)=Terms(87); K(6*i-1,6*i+4)=Terms(88); K(6*i-1,6*i+5)=Terms(89); K(6*i-1,6*i+6)=Terms(90);
      K(6*i  ,6*i-11)=Terms(91); K(6*i  ,6*i-10)=Terms(92);   K(6*i  ,6*i-9)=Terms(93);   K(6*i  ,6*i-8)=Terms(94); K(6*i  ,6*i-7)=Terms(95);    K(6*i  ,6*i-6)=Terms(96);    K(6*i  ,6*i-5)=Terms(97);    K(6*i  ,6*i-4)=Terms(98);    K(6*i  ,6*i-3)=Terms(99);    K(6*i ,6*i-2)=Terms(100);    K(6*i ,6*i-1)=Terms(101);    K(6*i ,6*i)=Terms(102);   K(6*i ,6*i+1)=Terms(103); K(6*i ,6*i+2)=Terms(104); K(6*i ,6*i+3)=Terms(105); K(6*i ,6*i+4)=Terms(106); K(6*i ,6*i+5)=Terms(107); K(6*i ,6*i+6)=Terms(108);
    end
   
    %Fill the elements of the Jacobian matrix corresponding to the
    %ghost cells with K=1 to keep values unaltered
    
    % Two ghost cells upstream (i=1 and i=2) with 6 equations per cell: 12 elements with K =1
    K(1,1)=1; K(2,2)=1; K(3,3)=1; K(4,4)=1; K(5,5)=1; K(6,6)=1;
    K(7,7)=1; K(8,8)=1; K(9,9)=1; K(10,10)=1; K(11,11)=1; K(12,12)=1;
    
    % Two ghost cells downstream (i=N and i=N-1) with 6 equations per cell: 12 elements with K =1
    K(6*length(x)-11,6*length(x)-11)=1; K(6*length(x)-10,6*length(x)-10)=1;
    K(6*length(x)-9,6*length(x)-9)=1;  K(6*length(x)-8,6*length(x)-8)=1;  
    K(6*length(x)-7,6*length(x)-7)=1;  K(6*length(x)-6,6*length(x)-6)=1; 
    K(6*length(x)-5,6*length(x)-5)=1; K(6*length(x)-4,6*length(x)-4)=1;
    K(6*length(x)-3,6*length(x)-3)=1; K(6*length(x)-2,6*length(x)-2)=1;
    K(6*length(x)-1,6*length(x)-1)=1; K(6*length(x),6*length(x))=1;