%% Instantaneous Plot

%Plot singuar points
kk=1;
xSingCell=0;
zsSingCell=0;
for k=1:length(SingCell)
    if SingCell(k)>0
        xSingCell(kk)=x(SingCell(k));
        zsSingCell(kk)=zs(SingCell(k));
        kk=kk+1;
    end
end

pause (0.001)
subplot(2,1,1)
plot(x,zb,'k',x,zsstv,'r',x,zs,'b',xSingCell,zsSingCell,'rsq','LineWidth',1.5)
title({'VAM model with multicrit, new h*u1 eq. and Ghamry-Steffler turb.'})
xlim([x(1) x(end)])
ylim([-0.1 0.6])
yticks(-10:0.05:10)
xticks(-20:0.5:20)
ylabel('{\it z_s} (m)')
xlabel('{\it x} (m)')
legend({'Bed profile','dSV model','VAM model','Singular Cells'},'NumColumns',2)
grid on
subplot(2,1,2)
plot(x,h.*u1,'r',x,h.*wmed,'k',x,q,'m',x,p1/(ro),'g',x,p2/(ro),'k--',xSingCell,0*zsSingCell,'rsq','LineWidth',1.5)
title({['CFL = ',num2str(CFL),', dx = ',num2str(dx),' m, t = ',num2str(t),' s']})
xlim([x(1) x(end)])
ylim([-1 1])
yticks(-10:0.2:10)
xticks(-20:0.5:20)
ylabel('head (m)')
xlabel('{\it x} (m)')
legend({'h*u1 - VAM','h*wmed - VAM','q - VAM','p1/{\rho} - VAM','p2/{\rho} - VAM','Singular Cells'},'Location','southeast','NumColumns',2)
set(gca,'fontname','Tmaxs')  % Set it to Tmaxs
set(gcf,'Position',[100 200 1000 600])
grid on
