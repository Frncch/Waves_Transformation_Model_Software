%% Evolve routine

%VAM and Saint-Venant
S=[0*x;
   ghdzbdx(1,:);
   0*x;
   0*x;
   0*x;
   0*x;
   ghdzbdx(2,:)];
U=Uold-(dt/dx)*flux-dt*S; 
h=U(1,:);      q=U(2,:);          
u1=U(3,:);     wmed=U(4,:)./h;     diffe=12*U(5,:)./(h.^2);   
hstv=U(6,:);   qstv=U(7,:); 
for i=1:length(x)
    if h(i)<htol
        q(i)=0; u1(i)=0; wmed(i)=0; diffe(i)=0;
    end
    if hstv(i)<htol
        qstv(i)=0; 
    end
    if h(i)<0
        h(i)=0; q(i)=0; u1(i)=0; wmed(i)=0; diffe(i)=0;
    end
    if hstv(i)<0
        hstv(i)=0; qstv(i)=0; 
    end
end