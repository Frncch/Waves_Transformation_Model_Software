%% MUSCL

%Cell i the interface i+1/2 
%varL05 means values of the variables at the left side of an interface

%The computational domain is divided in N cells. Ghost cells are located at
%i=1, i=2, i=N-1 and i=N.
%Computational cells are thus i=3, 4,....., N-3, N-2.
for i=1:length(x)
    U(8,i)=U(1,i)+zb(i); %SGM for VAM
    U(9,i)=U(6,i)+zb(i); %SGM for StV
    if U(1,i)==0
        FrVAM(i)=0;
    else
        FrVAM(i)=((U(2,i)^2)/(9.81*U(1,i)^3))^0.5;
    end
    viVAM(i)=0.5*(1-cos(pi*FrVAM(i)/Flim));
    if U(6,i)==0
        FrSTV(i)=0;
    else
        FrSTV(i)=((U(7,i)^2)/(9.81*U(6,i)^3))^0.5;
    end
    viSTV(i)=0.5*(1-cos(pi*FrSTV(i)/Flim));
end
for i=2:length(x)-1
    for k=1:9
        DU=U(k,i)-U(k,i-1);
        DD=U(k,i+1)-U(k,i);
        
        limiters
        
        PIL(k)=U(k,i)-0.5*delta;
        PIR(k)=U(k,i)+0.5*delta;
    end
    %SGM or DGM method - Computation of water depths at cell faces
    if FrVAM(i)<=Flim
       PIL(1)=PIL(1)*viVAM(i)+(1-viVAM(i))*(PIL(8)-zbL(i));
       PIR(1)=PIR(1)*viVAM(i)+(1-viVAM(i))*(PIR(8)-zbR(i)); 
    end
    if FrSTV(i)<=Flim
       PIL(6)=PIL(6)*viSTV(i)+(1-viSTV(i))*(PIL(9)-zbL(i));
       PIR(6)=PIR(6)*viSTV(i)+(1-viSTV(i))*(PIR(9)-zbR(i)); 
    end
    
    %In a dry cell the reconstruction is not allowed; thus, water depths at interfaces
    %are set to zero. All the depths are zero in a cell marked computationally as dry
    %This is true in a full dry cell, but incorrect in a partially-filled cell
    if h(i)<=htol
        PIL(1)=0;
        PIR(1)=0;
    end
    if hstv(i)<=htol
        PIL(6)=0;
        PIR(6)=0;
    end
    %Ensure positivity in water depths at interfaces
    if PIL(1)<0
        PIL(1)=0;        
    end
    if PIR(1)<0
        PIR(1)=0;        
    end
    if PIL(6)<0
        PIL(6)=0;        
    end
    if PIR(6)<0
        PIR(6)=0;        
    end
    if PIL(1)<htol 
        PIL(2)=0;
    end
    if PIR(1)<htol
        PIR(2)=0;
    end
    if PIL(6)<htol 
        PIL(7)=0;
    end
    if PIR(6)<htol
        PIR(7)=0;
    end
    for k=1:7
        %Temporal evolution of PIL and PIR (for second order time accuracy)
        evolveHancock
        deltaflux=0.5*(dt/dx)*(FIL(k)-FIR(k));
        deltasource(k)=0.5*dt*deltasource(k);
        
        %Assignation of boundary-extrapolated (BEXT) values to temporal arrays
        %BEXT(j,k,i) is the vector of boundary extrapolated values at cell i, with k as the conservation
        %law index (1=mass, 2=x-momentum, 3=z-mometum, 4=moment x-moment, 5=moment z-momentum, 6=massSTV, 7=x-momentumSTV)
        %and j as the face side index (1=left face, 2=right face)        
        BEXT(1,k,i)=PIL(k) + deltaflux + deltasource(k);
        BEXT(2,k,i)=PIR(k) + deltaflux + deltasource(k);
    end
    %preserve positivity in water depths
    if BEXT(1,1,i)<0 
        BEXT(1,1,i)=0;
        BEXT(1,2,i)=0;
    end
    if BEXT(2,1,i)<0 
        BEXT(2,1,i)=0;
        BEXT(2,2,i)=0;
    end
    if BEXT(1,6,i)<0 
        BEXT(1,6,i)=0;
        BEXT(1,7,i)=0;
    end
    if BEXT(2,6,i)<0 
        BEXT(2,6,i)=0;
        BEXT(2,7,i)=0;
    end
    %avoid high velocity in data
    if BEXT(1,1,i)<htol 
        BEXT(1,2,i)=0;
    end
    if BEXT(2,1,i)<htol
        BEXT(2,2,i)=0;
    end
    if BEXT(1,6,i)<htol 
        BEXT(1,7,i)=0;
    end
    if BEXT(2,6,i)<htol
        BEXT(2,7,i)=0;
    end
end
%At the interface of a full wet cell and a dry cell a jump in water depths may be formed
%However, the dry cell is in reality partially filled with water
%That is, the dry front in contained inside the computationally dry cell. Therefore, an
%unrealistic dry-bed dam break wave problem at the interface of a full-wet and full-dry cells is formed
%Remember that a cell is marked computationally as dry with zero water depth (cell-averaged value),
%but physically there is a portion of water inside this cell if it is in contact with a full-wet cell
for i=2:length(x)-1
    if FrVAM(i)<=Flim
        %VAM
        %dry front is on the right
        if h(i)<(zb(i+1)-zb(i)) && h(i+1)<=htol
            BEXT(1,1,i+1)=BEXT(2,1,i);
            BEXT(1,2,i+1)=-BEXT(2,2,i);
        end
        %dry front is on the left
        if h(i)<(zb(i-1)-zb(i)) && h(i-1)<=htol
            BEXT(2,1,i-1)=BEXT(1,1,i);
            BEXT(2,2,i-1)=-BEXT(1,2,i);
        end
    end
end
for i=2:length(x)-1
    if FrSTV(i)<=Flim
        %STV
        %dry front is on the right
        if hstv(i)<(zb(i+1)-zb(i)) && hstv(i+1)<=htol
            BEXT(1,6,i+1)=BEXT(2,6,i);
            BEXT(1,7,i+1)=-BEXT(2,7,i);
        end
        %dry front is on the left
        if hstv(i)<(zb(i-1)-zb(i)) && hstv(i-1)<=htol
            BEXT(2,6,i-1)=BEXT(1,6,i);
            BEXT(2,7,i-1)=-BEXT(1,7,i);
        end
    end
end