%Computation of dt to satisfy the Courant-Friedrichs-Lewy(CFL) condition and get a stable time stepping
%Computation of the wave celerity c at each cell i using the cell-averaged%values U(1,i)=flow depth(i) of VAM
%It is assumed that using the VAM h and q is more restrictive for the CFL condition than those from StV
N=length(x);
Smax = 0;

for i=1:N

%shallow water wave celerity
c(i) = (9.81 * U(1, i)) ^ 0.5;

%Local speed; where U(2,i)/U(1,i)=water velocity (i). Check zero water depths
if U(1, i) == 0
    SPELOC = 0;
else
    SPELOC = abs(U(2, i) / U(1, i)) + c(i);
end

if SPELOC >= Smax
    Smax = SPELOC;
end

end

%New value of dt using the fixed value of the CFL number; i.e. 0.5 to 1
if Smax == 0 
    dt = 0.001;
else
    dt = CFL * dx / Smax;
end

%Reduce dt for early times given the approximate Smax computation
if hd==0
    countlimit=50;
else
    countlimit=5;
end    
if count <= countlimit
dt = 0.2 * dt;
end

%Check that dt+t is not greater than Tmax and recompute dt if required
if t + dt > Tmax
    dt = Tmax - t;
end