%% Computation of the subcritical flow depth at the upstream boundary condition
% based on the specific energy at the upstream wall of the deposit
% Castro-Orgaz and Hager (2019), pg 82

function hsub=SpecificEnergyCondi(t,h1,qsub,g)

ha=(0.0015*t^4 - 0.032*t^3 + 0.1656*t^2 - 0.2503*t + 0.0393 + h1*100)/100;
E=ha;
hc=(qsub^2 /g)^(1/3);

gamma=acos(1-(27/4)*(E/hc)^(-3));

hsub=E*(1/3 + (2/3)*cos(gamma/3));