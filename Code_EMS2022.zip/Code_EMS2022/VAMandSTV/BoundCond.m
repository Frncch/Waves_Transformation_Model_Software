%% Ghost Cells to set boundary conditions

%Inlet condition
%STV
qstv(2)=qoldstv(3);   qstv(1)=qoldstv(4);
hstv(2)=SpecificEnergyCondi(t,h1,qstv(2),g);   hstv(1)=SpecificEnergyCondi(t,h1,qstv(1),g);     

%VAM
q(2)=qold(3);         q(1)=qold(4);
h(2)=SpecificEnergyCondi(t,h1,q(2),g);   h(1)=SpecificEnergyCondi(t,h1,q(1),g); 
u1(2)=u1old(3);       u1(1)=u1old(4);
wmed(2)=wmedold(3);   wmed(1)=wmedold(4);
diffe(2)=diffeold(3); diffe(1)=diffeold(4);
p1(2)=p1old(3);       p1(1)=p1old(4);
p2(2)=p1old(3);       p2(1)=p1old(4);


%Outlet condition
%STV
hstv(length(x)-1)=hstv(length(x)-2);   hstv(length(x))=hstv(length(x)-3); 
qstv(length(x)-1)=-qstv(length(x)-2);  qstv(length(x))=-qstv(length(x)-3); 
%VAM
h(length(x)-1)=h(length(x)-2);         h(length(x))=h(length(x)-2); 
q(length(x)-1)=-q(length(x)-2);        q(length(x))=-q(length(x)-2); 
u1(length(x)-1)=0*u1(length(x)-2);       u1(length(x))=0*u1(length(x)-2);
wmed(length(x)-1)=0*wmed(length(x)-2);   wmed(length(x))=0*wmed(length(x)-2);
diffe(length(x)-1)=0*diffe(length(x)-2); diffe(length(x))=0*diffe(length(x)-2);
p1(length(x)-1)=0*p1(length(x)-2);       p1(length(x))=0*p1(length(x)-2);
p2(length(x)-1)=0*p2(length(x)-2);       p2(length(x))=0*p2(length(x)-2);
