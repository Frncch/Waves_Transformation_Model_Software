%Vector of unknowns in VAM model
U=[h; q; h.*u1; h.*wmed; (h.^2).*diffe/12; hstv; qstv];
Uold=U;
