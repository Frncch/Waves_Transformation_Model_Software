%% Subcode to write the results from VAM computations
cd Exp1_results
    fullFileName = fullfile('VAM_Exp1_t0s.xlsx');
    xlswrite(fullFileName,[x',zbt0s',zst0s',ht0s',qt0s',u1t0s',p1t0s',p2t0s',wmedt0s',zsstvt0s',qstvt0s'])

    fullFileName = fullfile('VAM_Exp1_t048s.xlsx');
    xlswrite(fullFileName,[x',zbt048s',zst048s',ht048s',qt048s',u1t048s',p1t048s',p2t048s',wmedt048s',zsstvt048s',qstvt048s'])

    fullFileName = fullfile('VAM_Exp1_t1s.xlsx');
    xlswrite(fullFileName,[x',zbt1s',zst1s',ht1s',qt1s',u1t1s',p1t1s',p2t1s',wmedt1s',zsstvt1s',qstvt1s'])

    fullFileName = fullfile('VAM_Exp1_t2s.xlsx');
    xlswrite(fullFileName,[x',zbt2s',zst2s',ht2s',qt2s',u1t2s',p1t2s',p2t2s',wmedt2s',zsstvt2s',qstvt2s'])

    fullFileName = fullfile('VAM_Exp1_t3s.xlsx');
    xlswrite(fullFileName,[x',zbt3s',zst3s',ht3s',qt3s',u1t3s',p1t3s',p2t3s',wmedt3s',zsstvt3s',qstvt3s'])

    fullFileName = fullfile('VAM_Exp1_t4s.xlsx');
    xlswrite(fullFileName,[x',zbt4s',zst4s',ht4s',qt4s',u1t4s',p1t4s',p2t4s',wmedt4s',zsstvt4s',qstvt4s'])

    fullFileName = fullfile('VAM_Exp1_t5s.xlsx');
    xlswrite(fullFileName,[x',zbt5s',zst5s',ht5s',qt5s',u1t5s',p1t5s',p2t5s',wmedt5s',zsstvt5s',qstvt5s'])

    fullFileName = fullfile('VAM_Exp1_t6s.xlsx');
    xlswrite(fullFileName,[x',zbt6s',zst6s',ht6s',qt6s',u1t6s',p1t6s',p2t6s',wmedt6s',zsstvt6s',qstvt6s'])

    fullFileName = fullfile('VAM_Exp1_t7s.xlsx');
    xlswrite(fullFileName,[x',zbt7s',zst7s',ht7s',qt7s',u1t7s',p1t7s',p2t7s',wmedt7s',zsstvt7s',qstvt7s'])

    fullFileName = fullfile('VAM_Exp1_t8s.xlsx');
    xlswrite(fullFileName,[x',zbt8s',zst8s',ht8s',qt8s',u1t8s',p1t8s',p2t8s',wmedt8s',zsstvt8s',qstvt8s'])

    fullFileName = fullfile('VAM_Exp1_t9s.xlsx');
    xlswrite(fullFileName,[x',zbt9s',zst9s',ht9s',qt9s',u1t9s',p1t9s',p2t9s',wmedt9s',zsstvt9s',qstvt9s'])

    fullFileName = fullfile('VAM_Exp1_t10s.xlsx');
    xlswrite(fullFileName,[x',zbt10s',zst10s',ht10s',qt10s',u1t10s',p1t10s',p2t10s',wmedt10s',zsstvt10s',qstvt10s'])

    fullFileName = fullfile('VAM_Exp1_t11s.xlsx');
    xlswrite(fullFileName,[x',zbt11s',zst11s',ht11s',qt11s',u1t11s',p1t11s',p2t11s',wmedt11s',zsstvt11s',qstvt11s'])

    fullFileName = fullfile('VAM_Exp1_t12s.xlsx');
    xlswrite(fullFileName,[x',zbt12s',zst12s',ht12s',qt12s',u1t12s',p1t12s',p2t12s',wmedt12s',zsstvt12s',qstvt12s'])

    %Write Data results after slope and cantiliver correction
    fullFileName = fullfile('Data_Exp1_t0s.xlsx');
    xlswrite(fullFileName,[datat0(:,1),datat0(:,3)])        
    fullFileName = fullfile('Data_Exp1_t048s.xlsx');
    xlswrite(fullFileName,[datat048(:,1),datat048(:,3)])        
    fullFileName = fullfile('Data_Exp1_t1s.xlsx');
    xlswrite(fullFileName,[datat1(:,1),datat1(:,3)])        
    fullFileName = fullfile('Data_Exp1_t2s.xlsx');
    xlswrite(fullFileName,[datat2(:,1),datat2(:,3)])        
    fullFileName = fullfile('Data_Exp1_t3s.xlsx');
    xlswrite(fullFileName,[datat3(:,1),datat3(:,3)])        
    fullFileName = fullfile('Data_Exp1_t4s.xlsx');
    xlswrite(fullFileName,[datat4(:,1),datat4(:,3)])        
    fullFileName = fullfile('Data_Exp1_t5s.xlsx');
    xlswrite(fullFileName,[datat5(:,1),datat5(:,3)])        
    fullFileName = fullfile('Data_Exp1_t6s.xlsx');
    xlswrite(fullFileName,[datat6(:,1),datat6(:,3)])        
    fullFileName = fullfile('Data_Exp1_t7s.xlsx');
    xlswrite(fullFileName,[datat7(:,1),datat7(:,3)])        
    fullFileName = fullfile('Data_Exp1_t8s.xlsx');
    xlswrite(fullFileName,[datat8(:,1),datat8(:,3)])        
    fullFileName = fullfile('Data_Exp1_t9s.xlsx');
    xlswrite(fullFileName,[datat9(:,1),datat9(:,3)])        
    fullFileName = fullfile('Data_Exp1_t10s.xlsx');
    xlswrite(fullFileName,[datat10(:,1),datat10(:,3)])        
    fullFileName = fullfile('Data_Exp1_t11s.xlsx');
    xlswrite(fullFileName,[datat11(:,1),datat11(:,3)])        
    fullFileName = fullfile('Data_Exp1_t12s.xlsx');
    xlswrite(fullFileName,[datat12(:,1),datat12(:,3)])

    save('Exp1.mat')

    saveas(gcf,'Fig_Results_Exp1.jpg')
cd ..